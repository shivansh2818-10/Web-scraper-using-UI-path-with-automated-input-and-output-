chrome.runtime.onMessage.addListener(async function(msg, sender) {
    console.log(msg);
    clearAllCookies();

    if ((msg.from === 'content') && (msg.subject === 'load-popup')) {
        // Enable the page-action for the requesting tab

        chrome.pageAction.setPopup({ tabId: sender.tab.id, popup: msg.html }, () => {
            chrome.pageAction.show(sender.tab.id);
        });
    }

    if ((msg.from === 'content') && (msg.subject === 'clear-cookies')) {
        // Enable the page-action for the requesting tab

        clearAllCookies();
    }

});

async function clearAllCookies() {
    return new Promise((resolve) => {
        chrome.cookies.getAll({ domain: ".99acres.com" }, function(cookies) {

            for (var i = 0; i < cookies.length; i++) {
                console.log(cookies[i]);
                chrome.cookies.remove({ url: "https://" + cookies[i].domain + cookies[i].path, name: cookies[i].name });
            }
            resolve();
        });
    });

}

clearAllCookies();