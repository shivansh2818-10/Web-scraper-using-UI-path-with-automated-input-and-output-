function getUtils() {

    function findIdsNotInArray(ids, arrayIDs) {
        if (!arrayIDs || arrayIDs.length == 0) {
            return ids;
        }
        return ids.filter(id => !arrayIDs.find(arrayID => arrayID === id));
    }

    function pushIDArraytoCSV(idArray, csvString) {
        let result = csvString;
        if (idArray.length > 0) {
            const newcsvIds = idArray
                .reduce((accumulator, id, index) => accumulator + ',' + id);



            if (csvString && csvString.length !== 0) {
                result = result + ',' + newcsvIds;
            } else {
                result = newcsvIds;
            }
        }

        return result;
    }



    return {
        pushIDArraytoCSV: pushIDArraytoCSV,
        findIdsNotInArray: findIdsNotInArray

    }
}