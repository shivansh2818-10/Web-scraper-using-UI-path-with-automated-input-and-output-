RESIDENTAIL_BUY_SEARCH_PAGE_SCRAPER = {
    "name": "RESIDENTAIL_BUY_SEARCH_PAGE_SCRAPER",
    "match": "https://www.99acres.com/search/property/buy/residential-all/",
    "fields": [{
        "name": "Property Link",
        "attribute": "href",
        "selector": ".srpNw_tble th a",
        "type": "data"
    }],
    "groupSelector": ".srpWrap",
    "nextPage": {
        "attribute": "href",
        "name": "next-page",
        "selector": "a[name=nextbutton]"
    }
};


RESIDENTAIL_RENT_SEARCH_PAGE_SCRAPER = {
    "name": "RESIDENTAIL_RENT_SEARCH_PAGE_SCRAPER",
    "match": "https://www.99acres.com/search/property/rent/residential-all/",
    "fields": [{
        "name": "Property Link",
        "attribute": "href",
        "selector": ".srpttl a",
        "type": "data"
    }],
    "groupSelector": ".srpWrap",
    "nextPage": {
        "attribute": "href",
        "name": "next-page",
        "selector": "a[name=nextbutton]"
    }
};


RESIDENTAIL_PROJECTS_SEARCH_PAGE_SCRAPER = {
    "name": "RESIDENTAIL_PROJECTS_SEARCH_PAGE_SCRAPER",
    "match": "https://www.99acres.com/search/project/buy/residential/",
    "fields": [{
        "name": "Property Link",
        "attribute": "href",
        "selector": ".npsrp_head a",
        "type": "data"
    }],
    "groupSelector": ".srpWrap",
    "nextPage": {
        "attribute": "href",
        "name": "next-page",
        "selector": "a[name=nextbutton]"
    }
}


COMMERCIAL_PROJECTS_SEARCH_PAGE_SCRAPER = {
    "name": "COMMERCIAL_PROJECTS_SEARCH_PAGE_SCRAPER",
    "match": "https://www.99acres.com/search/project/buy/commercial/",
    "fields": [{
        "name": "Property Link",
        "attribute": "href",
        "selector": ".npsrp_head a",
        "type": "data"
    }],
    "groupSelector": ".srpWrap",
    "nextPage": {
        "attribute": "href",
        "name": "next-page",
        "selector": "a[name=nextbutton]"
    }
}

COMMERCIAL_PROPERTY_BUY_SEARCH_PAGE_SCRAPER = {
    "name": "COMMERCIAL_PROPERTY_BUY_SEARCH_PAGE_SCRAPER",
    "match": "https://www.99acres.com/search/property/buy/commercial-all/",
    "fields": [{
        "name": "Property Link",
        "attribute": "href",
        "selector": ".wrapttl a",
        "type": "data"
    }],
    "groupSelector": ".srpWrap",
    "nextPage": {
        "attribute": "href",
        "name": "next-page",
        "selector": "a[name=nextbutton]"
    }
}

COMMERCIAL_PROPERTY_LEASE_SEARCH_PAGE_SCRAPER = {
    "name": "COMMERCIAL_PROPERTY_LEASE_SEARCH_PAGE_SCRAPER",
    "match": "https://www.99acres.com/search/property/lease/commercial-all/",
    "fields": [{
        "name": "Property Link",
        "attribute": "href",
        "selector": ".wrapttl a",
        "type": "data"
    }],
    "groupSelector": ".srpWrap",
    "nextPage": {
        "attribute": "href",
        "name": "next-page",
        "selector": "a[name=nextbutton]"
    }
}
DEALER_RESIDENTIAL_SEARCH_PAGE_SCRAPER = {
    "name": "DEALER_RESIDENTIAL_SEARCH_PAGE_SCRAPER",
    "match": "https://www.99acres.com/search/dealer/buy/residential/",
    "fields": [{
        "name": "Property Link",
        "attribute": "href",
        "selector": ".dlr_decsblk a",
        "type": "data"
    }],
    "groupSelector": ".tuplefr",
    "nextPage": {
        "attribute": "href",
        "name": "next-page",
        "selector": "a[name=nextbutton]"
    }
}

DEALER_COMMERCIAL_SEARCH_PAGE_SCRAPER = {
    "name": "DEALER_COMMERCIAL_SEARCH_PAGE_SCRAPER",
    "match": "https://www.99acres.com/search/dealer/buy/commercial/",
    "fields": [{
        "name": "Property Link",
        "attribute": "href",
        "selector": ".dlr_decsblk a",
        "type": "data"
    }],
    "groupSelector": ".tuplefr",
    "nextPage": {
        "attribute": "href",
        "name": "next-page",
        "selector": "a[name=nextbutton]"
    }
}

SEARCH_PAGE_SCRAPERS = [
    RESIDENTAIL_BUY_SEARCH_PAGE_SCRAPER,
    RESIDENTAIL_RENT_SEARCH_PAGE_SCRAPER,
    RESIDENTAIL_PROJECTS_SEARCH_PAGE_SCRAPER,
    COMMERCIAL_PROJECTS_SEARCH_PAGE_SCRAPER,
    COMMERCIAL_PROPERTY_BUY_SEARCH_PAGE_SCRAPER,
    COMMERCIAL_PROPERTY_LEASE_SEARCH_PAGE_SCRAPER,
    DEALER_RESIDENTIAL_SEARCH_PAGE_SCRAPER,
    DEALER_COMMERCIAL_SEARCH_PAGE_SCRAPER,
];