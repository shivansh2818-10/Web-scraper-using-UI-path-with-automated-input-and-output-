const MSG_POPUP_REQUEST_DOMAIN = 'MSG_POPUP_REQUEST_DOMAIN';
const MSG_START_CRAWL = 'MSG_START_CRAWL';
const MSG_SCRAP_OBJECT_UPDATE = 'MSG_SCRAP_OBJECT_UPDATE';
const MSG_IS_SEARCH_PAGE = 'MSG_IS_SEARCH';
const MSG_IS_LOGGEDIN = 'MSG_IS_LOGGEDIN';
const MSG_SKIP_SEARCH_PAGE = 'MSG_SKIP_SEARCH_PAGE';
const MSG_SCRAPER_OBJECT_UPDATE = 'MSG_SCRAPER_OBJECT_UPDATE';


function getActiveTab() {
    return new Promise((resolve => {
        chrome.tabs.query({
            active: true,
            currentWindow: true
        }, function(tabs) {
            // ...and send a request for the DOM info...
            resolve(tabs[0].id);

        });
    }));
}

function sendMsgToActiveTab(msg) {
    return new Promise((resolve) => {
        getActiveTab().then(tabid => {
            chrome.tabs.sendMessage(
                tabid, msg, (data) => {

                    resolve(data);
                });
        });
    });


}

function sendMsgToExtension(msg) {

    chrome.runtime.sendMessage(msg);
}

function setPopUp(html) {
    chrome.runtime.sendMessage({
        from: 'content',
        subject: 'load-popup',
        html: html
    });

}

function clearAllCokkies() {
    chrome.runtime.sendMessage({
        from: 'content',
        subject: 'clear-cookies'
    });

}