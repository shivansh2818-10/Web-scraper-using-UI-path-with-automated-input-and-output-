function getPageScraper(scraper) {


    function validate() {
        const count = $(scraper.validateSelector).length;
        return count;
    }



    function isLoggedIn() {
        const count = $(scraper.login.selector).length;
        if (count === 0) {
            return true;
        } else {
            return false;
        }

    }

    function getNextPage() {
        if (scraper.nextPage) {
            return scrapFieldInfoInDocument(scraper.nextPage);
        }
    }

    function scrapePage() {

        if (scraper.groupSelector) {
            return scrapeMultiRecord(scraper);
        } else {
            return scrapeSingleRecord(scraper);
        }


    }

    function scrapeMultiRecord(scraper) {
        const scrapResults = [];
        return new Promise((resolve) => {
            if (scraper.groupSelector) {
                $(scraper.groupSelector).each(function(i, prodElement) {

                    const scrapedItem = scrapeMultiRecordItem(scraper, prodElement);
                    scrapResults.push(scrapedItem);

                });
            }

            resolve({ scraper: scraper.name, results: scrapResults });

        });


    }

    function scrapeMultiRecordItem(scraper, productElement) {
        const scrapResult = [];
        if (scraper.fields.length > 0) {

            scraper.fields.forEach(function(field) {
                let fieldResult = { name: field.name, value: '' };
                fieldResult.value = scrapFieldInfoInElement(field, productElement);
                scrapResult.push(fieldResult);
            });

        }
        return scrapResult;
    }


    function scrapeSingleRecord(scraper) {

        if (scraper.fields.length > 0) {
            return new Promise((resolve) => {
                const scrapResult = [];
                scraper.fields.forEach(function(field) {
                    let fieldResult = { name: field.name, value: '' };
                    fieldResult.value = scrapFieldInfoInDocument(field);
                    scrapResult.push(fieldResult);
                });

                resolve({ scraper: scraper.name, result: scrapResult })
            });
        } else {
            return Promise.reject('No Product Selector Defined')
        }

    }

    function isCaptchPresent() {
        if ($(`iframe[src*='https://www.google.com/recaptcha/']:first`).length > 0) {

            return true;
        } else {
            return false;
        }
    }

    function scrapFieldInfoInDocument(field) {
        let fieldValue = 'undefined';
        let fieldElement = null;
        if (field.selector.length > 0) {
            if ($(field.selector) && $(field.selector).length > 0) {
                fieldElement = $(field.selector)[0];
                if (fieldElement) {
                    if (field.attribute.length > 0) {
                        if (field.attribute === 'next') {
                            fieldValue = $(field.selector).next().text();
                        } else {
                            fieldValue = $(fieldElement).attr(field.attribute);
                        }
                    } else {
                        fieldValue = $(fieldElement).text();
                    }
                }


            }
        }
        return fieldValue;
    }

    function scrapFieldInfoInElement(field, productElement) {
        let fieldValue = 'undefined';

        if (field.selector.length > 0) {
            if ($(productElement).find(field.selector)) {
                const fieldElement = $(productElement).find(field.selector)[0];
                if (field.attribute.length > 0) {
                    fieldValue = $(fieldElement).attr(field.attribute);
                } else {
                    fieldValue = $(fieldElement).text();
                }
            }
        }
        return fieldValue;
    }


    return {
        scrapePage: scrapePage,
        isCaptchPresent: isCaptchPresent,
        isLoggedIn: isLoggedIn,
        validate: validate,
        getNextPage: getNextPage
    };
}