setPopUp('popup.html');
const BLOCKED_PAGE_TIME_OUT = 5 * 1000;
const SCROLL_WAIT_TIME = 1000;
const storageProvider = getStorageInstance();
const dbProvider = getDBInstance();

let DomainProps = {
    baseHref: '',
    domain: '',
    baseUrl: '',
    pageUrl: '',
    favicon: '',
};
const Flags = {
    isSearchPage: false,
    isProjectPage: false
}
Flags.isSearchPage = false;


let ScraperObject = {};

let currentPageScraper = null;




$(document).ready(function() {

    initContent();

});





async function initContent() {

    setBaseNDomain();





    if (DomainProps.domain === '99acres.com') {
        chrome.runtime.onMessage.addListener(msgListener);

        const scraperStatus = await storageProvider.getScraperStatus();

        if (scraperStatus === 'ON') {

            beginScraping();
        }

    }
}

async function setCurrentScraper() {
    const isAllSearchPagesIndexed = await storageProvider.getAllSearchPagesIndexed();


    if (!isAllSearchPagesIndexed) {
        Flags.isSearchPage = true;
        currentPageScraper = SEARCH_PAGE_SCRAPERS
            .find(scraper => scraper.name === ScraperObject.searchPageScraper);
    } else {
        //Its a single Page.
        switch (ScraperObject.searchPageScraper) {
            case 'RESIDENTAIL_BUY_SEARCH_PAGE_SCRAPER':
                {
                    if (isProjectPropertyPage()) {
                        currentPageScraper = BUY_RESEDENTIAL_PROJECT_PAGE_SCRAPER;
                    } else {
                        currentPageScraper = BUY_RESEDENTIAL_PROPERTY_PAGE_SCRAPER;
                    }
                    break;
                }
            case 'RESIDENTAIL_RENT_SEARCH_PAGE_SCRAPER':
                {
                    currentPageScraper = RENT_RESEDENTIAL_PROPERTY_PAGE_SCRAPER;
                    break;
                }
            case 'RESIDENTAIL_PROJECTS_SEARCH_PAGE_SCRAPER':
                {
                    currentPageScraper = PROJECT_RESIDENTIAL_PAGE_SCRAPER;
                    break;
                }
            case 'COMMERCIAL_PROJECTS_SEARCH_PAGE_SCRAPER':
                {
                    currentPageScraper = PROJECT_COMMERCIAL_PAGE_SCRAPER;
                    break;
                }
            case 'COMMERCIAL_PROPERTY_BUY_SEARCH_PAGE_SCRAPER':
                {
                    currentPageScraper = BUY_COMMERCIAL_PROPERTY_PAGE_SCRAPER;
                    break;
                }
            case 'COMMERCIAL_PROPERTY_LEASE_SEARCH_PAGE_SCRAPER':
                {
                    currentPageScraper = RENT_COMMERCIAL_PROPERTY_PAGE_SCRAPER;
                    break;
                }
            case 'DEALER_RESIDENTIAL_SEARCH_PAGE_SCRAPER':
                {
                    break;
                }
            case 'DEALER_COMMERCIAL_SEARCH_PAGE_SCRAPER':
                {
                    break;
                }


        }
    }




}

async function scrollPage() {
    return new Promise((resolve, reject) => {
        const scrollingElement = (document.scrollingElement || document.body);
        window.scrollTo(0, scrollingElement.scrollHeight);
        setTimeout(() => resolve(), SCROLL_WAIT_TIME);
    });
}


async function beginScraping() {

    const blockedPageFlag = await isBlockedPage();
    if (blockedPageFlag) {
        clearAllCokkies();
        setInterval(function() {
            location.reload();
        }, BLOCKED_PAGE_TIME_OUT)
    } else {
        ScraperObject = await dbProvider.getScraperObject();
        await setCurrentScraper();
        if (currentPageScraper.name === 'PROJECT_RESIDENTIAL_PAGE_SCRAPER' ||
            currentPageScraper.name === 'PROJECT_COMMERCIAL_PAGE_SCRAPER') {
            await scrollPage();
        }
        console.log(currentPageScraper);

        if (Flags.isSearchPage) {
            await scrapSearchPage();

        } else {
            console.log('Scraping Product Page');
            await scrapProductPage();
        }



        await dbProvider.saveScraperObject(ScraperObject);
        sendMsgToExtension({
            from: 'content.js',
            subject: MSG_SCRAPER_OBJECT_UPDATE,
            data: ScraperObject
        })
        moveNextPage();
    }


}



function getProductIds(scrapeResult) {
    let productIds = [];
    let propertyID = '';
    scrapeResult
        .forEach(element => {
            const tokens = element[0].value.split('-');
            const lastToken = tokens[tokens.length - 1];
            index = lastToken.indexOf('?');
            if (index !== -1) {
                propertyID = lastToken.substring(0, index);
            } else {
                propertyID = lastToken;
            }

            productIds.push(propertyID);
        });
    if (currentPageScraper === RESIDENTAIL_PROJECTS_SEARCH_PAGE_SCRAPER ||
        currentPageScraper === COMMERCIAL_PROJECTS_SEARCH_PAGE_SCRAPER) {
        productIds = productIds.map(productid => `--npxid-${productid}`);
    }
    return productIds;
}



async function scrapProductPage() {

    console.log(currentPageScraper);
    if (currentPageScraper) {
        const pageScraper = getPageScraper(currentPageScraper);
        const result = await pageScraper.scrapePage();
        console.log(result);
        if (result.result[0].name === 'Propertyid') {
            console.log(`Saving Property`);
            await dbProvider.addProperty(result);
        } else {
            console.log(`Saving Project`);
            await dbProvider.addProject(result);
        }

        ScraperObject.currentProductToScrapIndex = ScraperObject.currentProductToScrapIndex + 1;

    }
}



async function scrapSearchPage() {


    if (currentPageScraper) {
        const pageScraper = getPageScraper(currentPageScraper);
        const result = await pageScraper.scrapePage();
        console.log(result);
        const productids = getProductIds(result.results);

        ScraperObject.searchPagesIndexed = ScraperObject.searchPagesIndexed + 1;

        ScraperObject.allPropertyIds = getUtils().pushIDArraytoCSV(productids, ScraperObject.allPropertyIds);
        ScraperObject.productPagesFound = ScraperObject.productPagesFound + productids.length;
    }
}





function msgListener(msg, sender, response) {

    switch (msg.subject) {

        case MSG_POPUP_REQUEST_DOMAIN:
            response(DomainProps);
            break;

        case MSG_START_CRAWL:
            beginScraping();
            break;
    }

}


async function moveNextPage() {

    let nextPageUrl = '';
    if (Flags.isSearchPage) {
        const skipSearchPage = await storageProvider.getSkipSearchPage();
        if (!skipSearchPage) {
            nextPageUrl = await getNextSearchPageUrl();
            console.log(nextPageUrl)
            if (!nextPageUrl || nextPageUrl.length === 0) {
                //Search Pages are all crawled. Move to single page Crawling.
                await storageProvider.enableAllSearchPagesIndexed();
                await initSinglePageCrwaling();
                nextPageUrl = await getNextProductPageUrl();
            }
        } else {
            //Skip the search page and move to product pages.
            await storageProvider.enableAllSearchPagesIndexed();
            await initSinglePageCrwaling();
            nextPageUrl = await getNextProductPageUrl();
        }

    } else {
        nextPageUrl = await getNextProductPageUrl();

    }
    console.log(nextPageUrl);
    if (nextPageUrl.search('undefined') === -1) {
        await clearAllCokkies();

        window.location.href = nextPageUrl;
    }

}

async function initSinglePageCrwaling() {
    console.log(`In InitSingle PAge Crawling..`);
    let productsToScrap = [];
    if (currentPageScraper.name === 'RESIDENTAIL_PROJECTS_SEARCH_PAGE_SCRAPER' ||
        currentPageScraper.name === 'COMMERCIAL_PROJECTS_SEARCH_PAGE_SCRAPER') {

        productsToScrap = await getAllProjectPagesToCrawl();
    } else {
        productsToScrap = await getAllPropertyPagesToCrawl();
    }


    await storageProvider.addProductIds(productsToScrap);
    ScraperObject.totalProductsToScrap = productsToScrap.length;
    ScraperObject.currentProductToScrapIndex = 0;
    await dbProvider.saveScraperObject(ScraperObject);


}



async function getAllPropertyPagesToCrawl() {
    const existingPropertyIDs = await dbProvider.getAllPropertyIds();
    let allPropertyIdsInResult = ScraperObject.allPropertyIds
        .split(',')
        .map(propid => propid.toUpperCase());
    console.log(allPropertyIdsInResult);
    console.log(existingPropertyIDs);
    const propertyIDSToScrap = getUtils().findIdsNotInArray(allPropertyIdsInResult, existingPropertyIDs);
    console.log(propertyIDSToScrap);
    return propertyIDSToScrap;
}

async function getAllProjectPagesToCrawl() {
    const existingPropertyIDs = await dbProvider.getAllProjectIds();
    let allPropertyIdsInResult = ScraperObject.allPropertyIds.split(',');
    allPropertyIdsInResult = allPropertyIdsInResult.map(projectid => {
        let tokens = projectid.split('-');
        return tokens[tokens.length - 1].toUpperCase();
    });
    const propertyIDSToScrap = getUtils().findIdsNotInArray(allPropertyIdsInResult, existingPropertyIDs);
    return propertyIDSToScrap;

}


async function getNextSearchPageUrl() {
    let nextPageUrl = '';
    const nextPageUrlFragment = await getPageScraper(currentPageScraper).getNextPage();
    console.log(nextPageUrlFragment);
    if (nextPageUrlFragment && nextPageUrlFragment !== 'undefined') {
        nextPageUrl = DomainProps.baseUrl + '/' + nextPageUrlFragment;
    }
    console.log(`NextPageUrl in getNextSearchPageUrl():${nextPageUrl}`);
    return nextPageUrl;
}

async function getNextProductPageUrl() {
    const nextProductId = await storageProvider.getNextProductId();
    console.log(nextProductId);
    let nextPageUrl = '';
    if (nextProductId) {
        if (currentPageScraper.name === 'PROJECT_RESIDENTIAL_PAGE_SCRAPER' ||
            currentPageScraper.name === 'PROJECT_COMMERCIAL_PAGE_SCRAPER' ||
            currentPageScraper.name === 'RESIDENTAIL_PROJECTS_SEARCH_PAGE_SCRAPER' ||
            currentPageScraper.name === 'COMMERCIAL_PROJECTS_SEARCH_PAGE_SCRAPER') {
            nextPageUrl = DomainProps.baseUrl + '/-npxid-' + nextProductId;
        } else {
            nextPageUrl = DomainProps.baseUrl + '/' + nextProductId;
        }

    } else {
        await storageInstance.resetProductIds();
        await storageInstance.stopScraper()
    }

    return nextPageUrl;
}



function setBaseNDomain() {
    DomainProps.domain = window.location.hostname.replace('www.', '');
    if (($(document).find('base').length > 0) && $($(document).find('base')[0]).attr('href')) {
        DomainProps.baseHref = $($(document).find('base')[0]).attr('href');
        DomainProps.baseHref = DomainProps.baseHref.trim();
        if (DomainProps.baseHref.length > 0 && DomainProps.baseHref[0] === '/') {
            DomainProps.baseHref = DomainProps.baseHref.substring(1);
        }
        if (DomainProps.baseHref.length > 0 && DomainProps.baseHref[DomainProps.baseHref.length - 1] === '/') {
            DomainProps.baseHref = DomainProps.baseHref.substring(0, DomainProps.baseHref.length - 1);
        }
    }
    DomainProps.baseUrl = window.location.protocol + '//' + window.location.hostname;
    if (DomainProps.baseHref.length > 0 && DomainProps.baseHref.indexOf(window.location.protocol) === -1) {
        DomainProps.baseUrl = window.location.protocol + '//' + window.location.hostname + '/' + DomainProps.baseHref;
    }
    DomainProps.pageUrl = window.location.href;
}



function isUrlAbsolute(url) {
    var r = new RegExp('^(?:[a-z]+:)?//', 'i');
    return r.test(url);
}





async function isBlockedPage() {

    const data = await getPageScraper(BLOCK_PAGE_VERIFIER_CONFIG).validate();
    if (data) {
        return true;
    } else {
        return false;
    }
}

function isProjectPropertyPage() {

    return isUrlProjectUrl(DomainProps.pageUrl);
}

function isUrlProjectUrl(url) {
    if (url.lastIndexOf('npspid') !== -1) {
        return true;
    } else {
        return false;
    }
}