function getDBInstance() {

    const DOWNLOAD_BATCH_SIZE = 100;
    const FIREBASE_PATH = 'https://acres-3e49e.firebaseio.com';

    function getUserDataScraperPath() {
        return `${FIREBASE_PATH}/userdata/scraper.json`;
    }

    function getAllPropertiesPath() {
        return `${FIREBASE_PATH}/properties.json`;
    }

    function getPropertyPathById(propertyid) {
        return `${FIREBASE_PATH}/properties/${propertyid}.json`;
    }

    function getProjectPathById(projectid) {
        return `${FIREBASE_PATH}/projects/${projectid}.json`;
    }

    function getProjectIDPath() {
        return `${FIREBASE_PATH}/projects.json?shallow=true`;
    }


    function getPropertyIDPath() {
        return `${FIREBASE_PATH}/properties.json?shallow=true`;
    }






    function saveScraperObject(scraperObject) {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: getUserDataScraperPath(),
                type: 'PUT',
                data: JSON.stringify(scraperObject),
                contentType: 'text/plain',
                dataType: 'json',
                success: function(data) {

                    if (data) {
                        resolve(true);
                    } else {
                        resolve(false);
                    }
                },
                error: function(error) {
                    reject(error);
                }
            });

        });
    }

    function getScraperObject() {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: getUserDataScraperPath(),
                type: 'GET',
                dataType: 'json',
                success: function(data) {

                    if (data) {
                        resolve(data);
                    } else {
                        resolve();
                    }
                },
                error: function(error) {
                    reject(error);
                }
            });

        });
    }



    function resetScraper() {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: getUserDataScraperPath(),
                type: 'PUT',
                data: JSON.stringify(null),
                contentType: 'text/plain',
                dataType: 'json',
                success: function(data) {
                    resolve(true);
                },
                error: function(error) {
                    reject(error);
                }
            });

        });
    }


    function addProperty(propertyData) {
        return new Promise((resolve, reject) => {
            const propid = propertyData.result.find(tuple => tuple.name === 'Propertyid').value;
            if (propid) {
                $.ajax({
                    url: getPropertyPathById(propid),
                    type: 'PUT',
                    data: JSON.stringify(propertyData),
                    contentType: 'text/plain',
                    dataType: 'json',
                    success: function(data) {
                        resolve(true);
                    },
                    error: function(error) {
                        reject(error);
                    }
                });

            } else {
                resolve();
            }

        });
    }

    function getProperty(propertyid) {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: getPropertyPathById(propertyid),
                type: 'GET',
                dataType: 'json',
                success: function(data) {

                    if (data) {
                        resolve(data);
                    } else {
                        resolve();
                    }
                },
                error: function(error) {
                    reject(error);
                }
            });

        });
    }

    function getPropertiesBatch(propertyIdBatch) {
        let promises = [];
        propertyIdBatch.forEach(propid => promises.push(getProperty(propid)));
        return Promise.all(promises)

    }

    async function getProperties(propertyIds, progressFn) {
        const propertiesMap = {
            'BUY_RESEDENTIAL_PROPERTY_PAGE_SCRAPER': [],
            'BUY_RESEDENTIAL_PROJECT_PAGE_SCRAPER': [],

        }
        for (let index = 0; index < propertyIds.length; index = index + DOWNLOAD_BATCH_SIZE) {

            progressFn(index);
            const properties = await getPropertiesBatch(propertyIds.slice(index, index + DOWNLOAD_BATCH_SIZE));
            if (properties && properties.length > 0) {
                console.log(properties);
                properties.forEach(property => {
                    if (property) {
                        if (!propertiesMap[property.scraper]) {
                            propertiesMap[property.scraper] = [];
                        }
                        propertiesMap[property.scraper].push(property.result);
                    }
                })
            }

        }

        return propertiesMap;
    }

    async function getProjects(projectiDs, progressFn) {
        const propertiesMap = {
            'PROJECT_COMMERCIAL_PAGE_SCRAPER': [],
            'PROJECT_RESIDENTIAL_PAGE_SCRAPER': [],
        }

        const projects = [];
        for (let index = 0; index < projectiDs.length; ++index) {
            const projectID = projectiDs[index];
            console.log(`Fetching ${index} of ${projects.length}`);
            progressFn(index);
            const property = await getProject(projectID);
            if (property) {
                if (!propertiesMap[property.scraper]) {
                    propertiesMap[property.scraper] = [];
                }
                propertiesMap[property.scraper].push(property.result);
            } else {
                console.log(`Unable to find ${projectID}`);
            }
        }
        return propertiesMap;
    }

    function addProject(projectData) {
        return new Promise((resolve, reject) => {
            const projid = projectData.result[0].value;
            if (projid) {
                $.ajax({
                    url: getProjectPathById(projid),
                    type: 'PUT',
                    data: JSON.stringify(projectData),
                    contentType: 'text/plain',
                    dataType: 'json',
                    success: function(data) {
                        resolve(true);
                    },
                    error: function(error) {
                        reject(error);
                    }
                });

            } else {
                resolve();
            }

        });
    }

    function getProject(projectid) {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: getProjectPathById(projectid.toUpperCase()),
                type: 'GET',
                dataType: 'json',
                success: function(data) {

                    if (data) {
                        resolve(data);
                    } else {
                        resolve();
                    }
                },
                error: function(error) {
                    reject(error);
                }
            });

        });
    }



    function getAllProjectIds() {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: getProjectIDPath(),
                type: 'GET',
                dataType: 'json',
                success: function(data) {

                    if (data) {
                        resolve(Object.keys(data));
                    } else {
                        resolve();
                    }
                },
                error: function(error) {
                    reject(error);
                }
            });

        });
    }

    function getAllPropertyIds() {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: getPropertyIDPath(),
                type: 'GET',
                dataType: 'json',
                success: function(data) {

                    if (data) {
                        resolve(Object.keys(data));
                    } else {
                        resolve();
                    }
                },
                error: function(error) {
                    reject(error);
                }
            });

        });
    }




    return {

        getScraperObject: getScraperObject,
        saveScraperObject: saveScraperObject,
        resetScraper: resetScraper,
        addProperty: addProperty,
        getProperties: getProperties,
        addProject: addProject,
        getProjects: getProjects,
        getAllProjectIds: getAllProjectIds,
        getAllPropertyIds: getAllPropertyIds

    }
}