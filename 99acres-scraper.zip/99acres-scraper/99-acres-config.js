BUY_RESEDENTIAL_PROPERTY_PAGE_SCRAPER = {
    "name": "BUY_RESEDENTIAL_PROPERTY_PAGE_SCRAPER",
    "filename": "properties",
    "fields": [{
            "attribute": "",
            "name": "Propertyid",
            "rank": 0,
            "selector": "#propertyCode"
        },
        {
            "attribute": "",
            "name": "Title",
            "rank": 0.5,
            "selector": "#headerDescription"
        },
        {
            "attribute": "",
            "name": "Mini Description",
            "rank": 0.7,
            "selector": "title"
        },
        {
            "attribute": "",
            "name": "Location",
            "rank": 0.9,
            "selector": ".pdPropAddress"
        },
        {
            "attribute": "",
            "name": "Society",
            "rank": 0.95,
            "selector": "..socProjName"
        },

        {
            "attribute": "",
            "name": "Price",
            "rank": 1,
            "selector": "#pdPrice"
        },
        {
            "attribute": "",
            "name": "Availability",
            "rank": 1.5,
            "selector": "#Availability_Lbl"
        },
        {
            "attribute": "",
            "name": "Price Per Unit Area",
            "rank": 2,
            "selector": "#pricePerUnitArea"
        },
        {
            "attribute": "",
            "name": "Bed-Wash",
            "rank": 3,
            "selector": "#bedWash"
        },

        {
            "attribute": "",
            "name": "Super Builtup Area",
            "rank": 5,
            "selector": "#superbuiltupArea_span"
        },
        {
            "attribute": "",
            "name": "Builtup Area",
            "rank": 6,
            "selector": "#builtupArea_span"
        },
        {
            "attribute": "",
            "name": "Carpet Area",
            "rank": 7,
            "selector": "#carpetArea_span"
        },
        {
            "attribute": "",
            "name": "Area Units",
            "rank": 8,
            "selector": "#carpetAreaLabel"
        },

        {
            "attribute": "",
            "name": "Bedrooms",
            "rank": 9,
            "selector": "#bedRoomNum"
        },
        {
            "attribute": "",
            "name": "Bathrooms",
            "rank": 10,
            "selector": "#bathroomNum"
        },
        {
            "attribute": "",
            "name": "Balconies",
            "rank": 11,
            "selector": "#balconyNum"
        },
        {
            "attribute": "",
            "name": "Address",
            "rank": 13,
            "selector": "#address"
        },
        {
            "attribute": "",
            "name": "Total Floors",
            "rank": 14,
            "selector": "#floorNumLabel"
        },
        {
            "attribute": "",
            "name": "Facing",
            "rank": 15,
            "selector": "#facingLabel"
        },
        {
            "attribute": "",
            "name": "Overlooking",
            "rank": 16,
            "selector": "#overlooking"
        },
        {
            "attribute": "",
            "name": "Property Age",
            "rank": 17,
            "selector": "#agePossessionLbl"
        },
        {
            "attribute": "",
            "name": "Transaction Type",
            "rank": 18,
            "selector": "#transactionType"
        },
        {
            "attribute": "",
            "name": "Property Ownership",
            "rank": 19,
            "selector": "#propertyOwnership"
        },
        {
            "attribute": "",
            "name": "Flooring",
            "rank": 20,
            "selector": "#flooringType"
        },
        {
            "attribute": "",
            "name": "Furnishing",
            "rank": 21,
            "selector": "#furnishing"
        },
        {
            "attribute": "",
            "name": "Furnishing",
            "rank": 21,
            "selector": "#furnishing"
        },
        {
            "attribute": "",
            "name": "Width of Facing Road",
            "rank": 22,
            "selector": "#widthOfFacing"
        },
        {
            "attribute": "",
            "name": "Gated Community",
            "rank": 23,
            "selector": "#gatedCommunity"
        },
        {
            "attribute": "",
            "name": "Parking",
            "rank": 24,
            "selector": "#reservedParking"
        },
        {
            "attribute": "",
            "name": "Water Source",
            "rank": 25,
            "selector": "#waterSource"
        },
        {
            "attribute": "",
            "name": "Power Backup",
            "rank": 26,
            "selector": "#powerbackupLabel"
        },
        {
            "attribute": "",
            "name": "Total Project Area",
            "rank": 26.05,
            "selector": "#socAreaOccupied"
        },
        {
            "attribute": "",
            "name": "Open Area",
            "rank": 26.1,
            "selector": "#socOpenPercentage"
        }, {
            "attribute": "",
            "name": "Configuration",
            "rank": 26.2,
            "selector": "#socBedroomConf"
        },
        {
            "attribute": "",
            "name": "Tower Units",
            "rank": 26.3,
            "selector": "#towerUnits"
        },

        {
            "attribute": "",
            "name": "Description",
            "rank": 27,
            "selector": "#description"
        },
        {
            "attribute": "",
            "name": "Post Date",
            "rank": 30,
            "selector": ".pdPropDate"
        }, {
            "attribute": "data-apid",
            "name": "Dearler URL",
            "rank": 31,
            "selector": "#contactDealerBtn"
        },
        {
            "attribute": "",
            "name": "Contact Type",
            "rank": 32,
            "selector": "#contactDealerBtn"
        }
    ]
};

BUY_RESEDENTIAL_PROJECT_PAGE_SCRAPER = {
    "name": "BUY_RESEDENTIAL_PROJECT_PAGE_SCRAPER",
    "filename": "projects",
    "fields": [{
            "attribute": "",
            "name": "Propertyid",
            "rank": 0,
            "selector": "#propertyCode"
        },
        {
            "attribute": "",
            "name": "Price",
            "rank": 1,
            "selector": ".npPrice"
        },
        {
            "attribute": "",
            "name": "Project Name",
            "rank": 2,
            "selector": ".pseudoProjectName"
        }, {
            "attribute": "",
            "name": "Mini Description",
            "rank": 2.5,
            "selector": "title"
        },
        {
            "attribute": "href",
            "name": "Project Link",
            "rank": 3.5,
            "selector": ".pseudoProjectName"
        }, {
            "attribute": "",
            "name": "Project Area",
            "rank": 3,
            "selector": ".npPrjArea"
        },

        {
            "attribute": "",
            "name": "Floors",
            "rank": 4,
            "selector": "#cornerProperty"
        },
        {
            "attribute": "",
            "name": "Towers",
            "rank": 5,
            "selector": "#reservedProperty"
        },
        {
            "attribute": "",
            "name": "Title",
            "rank": 6,
            "selector": ".size-prop-type"
        },
        {
            "attribute": "",
            "name": "Address",
            "rank": 7,
            "selector": ".project-location span"
        },

        {
            "attribute": "",
            "name": "Super Bulitup Area",
            "rank": 8,
            "selector": ".npAreaPrice span"
        },
        {
            "attribute": "",
            "name": "Possesion",
            "rank": 9,
            "selector": ".npPossession"
        },
        {
            "attribute": "",
            "name": "Possesion Date",
            "rank": 10,
            "selector": ".npPossessionDate"
        },
        {
            "attribute": "",
            "name": "Floor Plans",
            "rank": 11,
            "selector": ".qaOptionTuple"
        },
        {
            "attribute": "",
            "name": "Basic Amenities",
            "rank": 12,
            "selector": ".xidBasicAmn"
        },
        {
            "attribute": "",
            "name": "Extended Amenities",
            "rank": 13,
            "selector": ".xidPrmAmn"
        },
        {
            "attribute": "",
            "name": "Posted On",
            "rank": 14,
            "selector": ".pdPropDate"
        }, {
            "attribute": "data-apid",
            "name": "Dearler URL",
            "rank": 31,
            "selector": "#contactDealerBtn"
        },
        {
            "attribute": "",
            "name": "Contact Type",
            "rank": 32,
            "selector": "#contactDealerBtn"
        }, {
            "attribute": "",
            "name": "Posted By",
            "rank": 30.5,
            "selector": ".pdDetailInfoOther"
        }



    ]


};


RENT_RESEDENTIAL_PROPERTY_PAGE_SCRAPER = {
    "name": "RENT_RESEDENTIAL_PROPERTY_PAGE_SCRAPER",
    "filename": "properties",
    "fields": [{
            "attribute": "",
            "name": "Propertyid",
            "rank": 0,
            "selector": "#propertyCode"
        },
        {
            "attribute": "",
            "name": "Title",
            "rank": 0.5,
            "selector": "#headerDescription"
        },
        {
            "attribute": "",
            "name": "Mini Description",
            "rank": 0.7,
            "selector": "title"
        },
        {
            "attribute": "",
            "name": "Location",
            "rank": 0.9,
            "selector": ".pdPropAddress"
        }, {
            "attribute": "",
            "name": "Society",
            "rank": 0.9,
            "selector": ".socProjName"
        },
        {
            "attribute": "",
            "name": "Price",
            "rank": 1,
            "selector": "#pdPrice"
        },
        {
            "attribute": "",
            "name": "Brokerage",
            "rank": 1.1,
            "selector": "#Brokerage"
        },
        {
            "attribute": "",
            "name": "Deposit",
            "rank": 1.2,
            "selector": "#Deposit"
        },
        {
            "attribute": "",
            "name": "Maintainance",
            "rank": 1.3,
            "selector": "#Maintanance_Charges"
        },
        {
            "attribute": "",
            "name": "Availability",
            "rank": 1.5,
            "selector": "#Availability_Lbl"
        },
        {
            "attribute": "",
            "name": "Price Per Unit Area",
            "rank": 2,
            "selector": "#pricePerUnitArea"
        },
        {
            "attribute": "",
            "name": "Bed-Wash",
            "rank": 3,
            "selector": "#bedWash"
        },

        {
            "attribute": "",
            "name": "Super Builtup Area",
            "rank": 5,
            "selector": "#superbuiltupArea_span"
        },
        {
            "attribute": "",
            "name": "Builtup Area",
            "rank": 6,
            "selector": "#builtupArea_span"
        },
        {
            "attribute": "",
            "name": "Carpet Area",
            "rank": 7,
            "selector": "#carpetArea_span"
        },
        {
            "attribute": "",
            "name": "Area Units",
            "rank": 8,
            "selector": "#carpetAreaLabel"
        },

        {
            "attribute": "",
            "name": "Bedrooms",
            "rank": 9,
            "selector": "#bedRoomNum"
        },
        {
            "attribute": "",
            "name": "Bathrooms",
            "rank": 10,
            "selector": "#bathroomNum"
        },
        {
            "attribute": "",
            "name": "Balconies",
            "rank": 11,
            "selector": "#balconyNum"
        },
        {
            "attribute": "",
            "name": "Additional Rooms",
            "rank": 11.5,
            "selector": "#additionalRooms"
        },
        {
            "attribute": "",
            "name": "Address",
            "rank": 13,
            "selector": "#address"
        },
        {
            "attribute": "",
            "name": "Total Floors",
            "rank": 14,
            "selector": "#floorNumLabel"
        },
        {
            "attribute": "",
            "name": "Facing",
            "rank": 15,
            "selector": "#facingLabel"
        },
        {
            "attribute": "",
            "name": "Overlooking",
            "rank": 16,
            "selector": "#overlooking"
        },
        {
            "attribute": "",
            "name": "Property Age",
            "rank": 17,
            "selector": "#agePossessionLbl"
        },


        {
            "attribute": "",
            "name": "Flooring",
            "rank": 20,
            "selector": "#flooringType"
        },
        {
            "attribute": "",
            "name": "Furnishing",
            "rank": 20.5,
            "selector": "#furnishingLabel"
        },
        {
            "attribute": "",
            "name": "Furnishing Details",
            "rank": 21,
            "selector": "#furnishing"
        },
        {
            "attribute": "",
            "name": "Feature Details",
            "rank": 21.5,
            "selector": "#features"
        },
        {
            "attribute": "",
            "name": "Width of Facing Road",
            "rank": 22,
            "selector": "#widthOfFacing"
        },
        {
            "attribute": "",
            "name": "Gated Community",
            "rank": 23,
            "selector": "#gatedCommunity"
        },
        {
            "attribute": "",
            "name": "Parking",
            "rank": 24,
            "selector": "#reservedParking"
        },
        {
            "attribute": "",
            "name": "Water Source",
            "rank": 25,
            "selector": "#waterSource"
        },
        {
            "attribute": "",
            "name": "Power Backup",
            "rank": 26,
            "selector": "#powerbackupLabel"
        },
        {
            "attribute": "",
            "name": "Total Project Area",
            "rank": 26.05,
            "selector": "#socAreaOccupied"
        },
        {
            "attribute": "",
            "name": "Open Area",
            "rank": 26.1,
            "selector": "#socOpenPercentage"
        }, {
            "attribute": "",
            "name": "Configuration",
            "rank": 26.2,
            "selector": "#socBedroomConf"
        },
        {
            "attribute": "",
            "name": "Tower Units",
            "rank": 26.3,
            "selector": "#towerUnits"
        },

        {
            "attribute": "",
            "name": "Description",
            "rank": 27,
            "selector": "#description"
        },
        {
            "attribute": "",
            "name": "Post Date",
            "rank": 30,
            "selector": ".pdPropDate"
        }, {
            "attribute": "data-apid",
            "name": "Dearler URL",
            "rank": 31,
            "selector": "#contactDealerBtn"
        },
        {
            "attribute": "",
            "name": "Contact Type",
            "rank": 32,
            "selector": "#contactDealerBtn"
        }
    ]

};

RENT_COMMERCIAL_PROPERTY_PAGE_SCRAPER = {
    "name": "RENT_COMMERCIAL_PROPERTY_PAGE_SCRAPER",
    "filename": "properties",
    "fields": [{
            "attribute": "value",
            "name": "Propertyid",
            "rank": 0,
            "selector": "input[name=prop_id]"
        },
        {
            "attribute": "",
            "name": "Mini Description",
            "rank": 1,
            "selector": "title"
        },
        {
            "attribute": "",
            "name": "Rent",
            "rank": 2,
            "selector": ".redPd"
        },
        {
            "attribute": "next",
            "name": "Maintainance",
            "rank": 2.1,
            "selector": "#maintanance_chargesLabel"
        },
        {
            "attribute": "next",
            "name": "Booking Amount",
            "rank": 2.2,
            "selector": "#booking_amountLabel"
        },
        {
            "attribute": "",
            "name": "Location",
            "rank": 2.5,
            "selector": "#AddTuplePd"
        },
        {
            "rank": 2.6,
            "attribute": "propname",
            "name": "Society",
            "selector": "#hiddenPd"
        },
        {
            "attribute": "",
            "name": "Address",
            "rank": 3,
            "selector": "#AddTuplePd"
        },
        {
            "attribute": "next",
            "name": "Facing",
            "rank": 3.1,
            "selector": "#facingLabel"
        },
        {
            "attribute": "next",
            "name": "Washrooms",
            "rank": 4,
            "selector": "#washroom_numLabel"
        },
        {
            "attribute": "next",
            "name": "Flooring",
            "rank": 4.05,
            "selector": "#flooringLabel"
        },
        {
            "attribute": "next",
            "name": "Availability",
            "rank": 4.1,
            "selector": "#availabilityLabel"
        },
        {
            "attribute": "next",
            "name": "Property Age",
            "rank": 4.2,
            "selector": "#ageLabel"
        },
        {
            "attribute": "next",
            "name": "Plot Area",
            "rank": 4.5,
            "selector": "#super_areaLabel"
        },
        {
            "attribute": "",
            "name": "Builtup Area",
            "rank": 5,
            "selector": "#builtupArea_span"
        }, {
            "attribute": "",
            "name": "Carpet Area",
            "rank": 6,
            "selector": "#carpetArea_span"
        },

        {
            "attribute": "next",
            "name": "Description",
            "rank": 9,
            "selector": "#descriptionLabel"
        },
        {
            "attribute": "",
            "name": "Features",
            "rank": 10,
            "selector": ".ameN"
        },
        {
            "attribute": "",
            "name": "Posted By",
            "rank": 11,
            "selector": "#ContactPdBody"
        },
        {
            "attribute": "",
            "name": "PostedOn",
            "rank": 40,
            "selector": ".PostdByPd"
        },
    ]


};

BUY_COMMERCIAL_PROPERTY_PAGE_SCRAPER = {
    "name": "BUY_COMMERCIAL_PROPERTY_PAGE_SCRAPER",
    "filename": "properties",
    "fields": [{
            "attribute": "propid",
            "name": "Propertyid",
            "rank": 0,
            "selector": "input[id=hiddenPd]"
        },
        {
            "attribute": "",
            "name": "Mini Description",
            "rank": 1,
            "selector": "title"
        },
        {
            "attribute": "",
            "name": "Price",
            "rank": 2,
            "selector": ".bspEmi .redPd"
        },
        {
            "attribute": "",
            "name": "Rate",
            "rank": 2.5,
            "selector": "#price_per_unit_areaLabel"
        },
        {
            "attribute": "",
            "name": "Location",
            "rank": 3,
            "selector": "#AddTuplePd"
        },
        {
            "rank": 3.05,
            "attribute": "propname",
            "name": "Society",
            "selector": "#hiddenPd"
        },
        {
            "attribute": "",
            "name": "Address",
            "rank": 3.1,
            "selector": "#AddTuplePd"
        },
        {
            "attribute": "next",
            "name": "Washrooms",
            "rank": 4,
            "selector": "#washroom_numLabel"
        },
        {
            "attribute": "next",
            "name": "Balconies",
            "rank": 4.1,
            "selector": "#balcony_numLabel"
        },
        {
            "attribute": "next",
            "name": "Flooring",
            "rank": 4.2,
            "selector": "#flooringLabel"
        },
        {
            "attribute": "",
            "name": "Area Range",
            "rank": 5,
            "selector": "#areaRange"
        },
        {
            "attribute": "",
            "name": "Super Area",
            "rank": 5.1,
            "selector": "#superArea_span"
        },
        {
            "attribute": "next",
            "name": "Builtup Area",
            "rank": 5.2,
            "selector": "#min_areaLabel"
        }, {
            "attribute": "",
            "name": "Carpet Area",
            "rank": 5.3,
            "selector": "#carpetArea_span"
        },
        {
            "attribute": "next",
            "name": "Availability",
            "rank": 7,
            "selector": "#availabilityLabel"
        },
        {
            "attribute": "next",
            "name": "Transaction",
            "rank": 7.1,
            "selector": "#transact_typeLabel"
        }, {
            "attribute": "next",
            "name": "Property Age",
            "rank": 7.2,
            "selector": "#ageLabel"
        },
        {
            "attribute": "next",
            "name": "Ownership",
            "rank": 7.3,
            "selector": "#owntypeLabel"
        },
        {
            "attribute": "next",
            "name": "Description",
            "rank": 9,
            "selector": "#descriptionLabel"
        },
        {
            "attribute": "",
            "name": "Features",
            "rank": 10,
            "selector": ".ameN"
        },
        {
            "attribute": "",
            "name": "Posted By",
            "rank": 11,
            "selector": "#ContactPdBody"
        },
        {
            "attribute": "",
            "name": "PostedOn",
            "rank": 40,
            "selector": ".PostdByPd"
        },
    ]


};

PROJECT_COMMERCIAL_PAGE_SCRAPER = {
    "name": "PROJECT_COMMERCIAL_PAGE_SCRAPER",
    "filename": "projects",
    "fields": [{
            "attribute": "val",
            "name": "Projectid",
            "rank": 0,
            "selector": "div[page=XIDPAGE]"
        },
        {
            "attribute": "",
            "name": "Mini Description",
            "rank": 1,
            "selector": "#item_desc"
        },
        {
            "attribute": "value",
            "name": "Project Name",
            "rank": 2,
            "selector": "input[id=npxidPROJ_NAME]"
        },
        {
            "attribute": "value",
            "name": "Location",
            "rank": 3,
            "selector": "input[id=npxidPROJ_LOCALITY]"
        },
        {
            "attribute": "value",
            "name": "Builder Name",
            "rank": 4,
            "selector": "input[id=npxidBUILDER_NAME]"
        },
        {
            "attribute": "value",
            "name": "Price Per SquareFoot",
            "rank": 5,
            "selector": "input[id=npxidRESALE_PRICE_SQFT]"
        },
        {
            "attribute": "value",
            "name": "Price",
            "rank": 6,
            "selector": "input[id=npxidPRICE_DISP]"
        },
        {
            "attribute": "value",
            "name": "Min Area",
            "rank": 7,
            "selector": "input[id=npxidMIN_AREA_SQFT]"
        },
        {
            "attribute": "value",
            "name": "Max Area",
            "rank": 8,
            "selector": "input[id=npxidMAX_AREA_SQFT]"
        },
        {
            "attribute": "value",
            "name": "Possesion Date",
            "rank": 9,
            "selector": "input[id=npxidPOSSESSION_DATE]"
        },
        {
            "attribute": "",
            "name": "Possesion",
            "rank": 9.1,
            "selector": ".factBox:contains('Possession')"
        },
        {
            "attribute": "",
            "name": "Configuration",
            "rank": 10,
            "selector": ".factBox:contains('Configurations')"
        },
        {
            "attribute": "",
            "name": "Towers",
            "rank": 11,
            "selector": ".factBox:contains('No. of Towers')",

        },
        {
            "attribute": "",
            "name": "Floors",
            "rank": 12,
            "selector": ".factBox:contains('No. of Floors')",

        },
        {
            "attribute": "",
            "name": "Units",
            "rank": 13,
            "selector": ".factBox:contains('No. of Units')",

        },
        {
            "attribute": "",
            "name": "Total Project Area",
            "rank": 14,
            "selector": ".factBox:contains('Total Project Area')",
        },
        {
            "attribute": "",
            "name": "Open Area",
            "rank": 15,
            "selector": ".factBox:contains('Open Area')",
        },
        {
            "attribute": "",
            "name": "Basic Ameneties",
            "rank": 16,
            "selector": ".xidBasicAmn",

        },
        {
            "attribute": "",
            "name": "Lifestyle Ameneties",
            "rank": 17,
            "selector": ".xidPrmAmn",

        },


    ]


};

PROJECT_RESIDENTIAL_PAGE_SCRAPER = {
    "name": "PROJECT_RESIDENTIAL_PAGE_SCRAPER",
    "filename": "projects",
    "fields": [{
            "attribute": "val",
            "name": "Projectid",
            "rank": 0,
            "selector": "div[page=XIDPAGE]"
        },
        {
            "attribute": "",
            "name": "Mini Description",
            "rank": 1,
            "selector": "#item_desc"
        },
        {
            "attribute": "value",
            "name": "Project Name",
            "rank": 2,
            "selector": "input[id=npxidPROJ_NAME]"
        },
        {
            "attribute": "value",
            "name": "Location",
            "rank": 3,
            "selector": "input[id=npxidPROJ_LOCALITY]"
        },
        {
            "attribute": "value",
            "name": "Builder Name",
            "rank": 4,
            "selector": "input[id=npxidBUILDER_NAME]"
        },
        {
            "attribute": "value",
            "name": "Price Per SquareFoot",
            "rank": 5,
            "selector": "input[id=npxidRESALE_PRICE_SQFT]"
        },
        {
            "attribute": "value",
            "name": "Price",
            "rank": 6,
            "selector": "input[id=npxidPRICE_DISP]"
        },
        {
            "attribute": "value",
            "name": "Min Area",
            "rank": 7,
            "selector": "input[id=npxidMIN_AREA_SQFT]"
        },
        {
            "attribute": "value",
            "name": "Max Area",
            "rank": 8,
            "selector": "input[id=npxidMAX_AREA_SQFT]"
        },
        {
            "attribute": "value",
            "name": "Possesion Date",
            "rank": 9,
            "selector": "input[id=npxidPOSSESSION_DATE]"
        },
        {
            "attribute": "",
            "name": "Possesion",
            "rank": 9.1,
            "selector": ".factBox:contains('Possession')"
        },
        {
            "attribute": "",
            "name": "Configuration",
            "rank": 10,
            "selector": ".factBox:contains('Configurations')"
        },
        {
            "attribute": "",
            "name": "Towers",
            "rank": 11,
            "selector": ".factBox:contains('No. of Towers')",

        },
        {
            "attribute": "",
            "name": "Floors",
            "rank": 12,
            "selector": ".factBox:contains('No. of Floors')",

        },
        {
            "attribute": "",
            "name": "Units",
            "rank": 13,
            "selector": ".factBox:contains('No. of Units')",

        },
        {
            "attribute": "",
            "name": "Total Project Area",
            "rank": 14,
            "selector": ".factBox:contains('Total Project Area')",
        },
        {
            "attribute": "",
            "name": "Open Area",
            "rank": 15,
            "selector": ".factBox:contains('Open Area')",
        },
        {
            "attribute": "",
            "name": "Basic Ameneties",
            "rank": 16,
            "selector": ".xidBasicAmn",

        },
        {
            "attribute": "",
            "name": "Lifestyle Ameneties",
            "rank": 17,
            "selector": ".xidPrmAmn",

        },

    ]


};



BLOCK_PAGE_VERIFIER_CONFIG = {
    "name": "BLOCK_PAGE_SCRAPER_CONFIG",
    "validateSelector": "._99gdprTitle",
}

PRODUCT_SCRAPERS = [
    BUY_RESEDENTIAL_PROPERTY_PAGE_SCRAPER,
    BUY_RESEDENTIAL_PROJECT_PAGE_SCRAPER,
    RENT_RESEDENTIAL_PROPERTY_PAGE_SCRAPER,
    RENT_COMMERCIAL_PROPERTY_PAGE_SCRAPER,
    BUY_COMMERCIAL_PROPERTY_PAGE_SCRAPER,
    PROJECT_COMMERCIAL_PAGE_SCRAPER,
    PROJECT_RESIDENTIAL_PAGE_SCRAPER
]