let DomainProps = {
    baseHref: '',
    domain: '',
    baseUrl: '',
    pageUrl: '',
    favicon: '',
};


const dbInstance = getDBInstance();
const storageInstance = getStorageInstance();
let scraperObject = null;
let cityName = '';
let categoryName = '';
let strDownloadProgress = '';


window.addEventListener('DOMContentLoaded', async function() {
    chrome.runtime.onMessage.addListener(async function(msg, sender) {
        console.log(msg);

        if (msg.subject === MSG_SCRAPER_OBJECT_UPDATE) {
            scraperObject = msg.data;

            updateView();
        }

    });
    addEventListeners();
    scraperObject = await dbInstance.getScraperObject();
    DomainProps = await sendMsgToActiveTab({
        from: 'home.js',
        subject: MSG_POPUP_REQUEST_DOMAIN
    });
    findCityNameNCategory(DomainProps);
    console.log(DomainProps);
    updateView();

});

function updateView() {
    console.log(scraperObject);
    $('#catcityHeading').html(`${scraperObject.categoryName}: ${scraperObject.cityName}`);
    $('#searchPageProgress').html(`Found ${scraperObject.productPagesFound} Products in   ${scraperObject.searchPagesIndexed} Search Pages`);

    $('#productProgress').html(`Indexing ${scraperObject.currentProductToScrapIndex} out of   ${scraperObject.totalProductsToScrap} Products`);
    $('#downloadProgress').html(strDownloadProgress);


}



function addEventListeners() {
    $('#btnStartExtarction').click(async function() {

        scraperObject = {
            baseUrl: DomainProps.pageUrl,
            cityName: cityName,
            categoryName: categoryName,
            searchPagesIndexed: 0,
            productPagesFound: 0,
            currentProductToScrapIndex: 0,
            allPropertyIds: [],
            searchPageScraper: SEARCH_PAGE_SCRAPERS
                .find(scraper => DomainProps.pageUrl.search(scraper.match) !== -1).name
        };
        await dbInstance.resetScraper();
        await dbInstance.saveScraperObject(scraperObject);
        await storageInstance.disableSkipSearchPage();
        await storageInstance.resetProductIds();
        await storageInstance.startScraper();
        await storageInstance.disableAllSearchPagesIndexed();
        sendMsgToActiveTab({
            from: 'home.js',
            subject: MSG_START_CRAWL
        });

    });

    $('#btnStopExtraction').click(async function() {

        scraperObject = {};
        await dbInstance.resetScraper()
        await storageInstance.resetProductIds();
        await storageInstance.stopScraper()
    });

    $('#btnPauseExtraction').click(async function() {

        storageInstance.pauseScraper();
    });

    $('#btnResumeExtraction').click(async function() {
        await storageInstance.startScraper();
        sendMsgToActiveTab({
            from: 'home.js',
            subject: MSG_START_CRAWL
        });
    });


    $('#btnSkipSearchPage').click(async function() {
        await storageInstance.enableSkipSearchPage();
    });

    $('#btnPropertyIds').click(async function() {
        const propertyids = await storageInstance.getPropertyIds();
        console.log(propertyids.split(',').length);
    });

    $('#btnDownloadData').click(async function() {
        const allPropIdsString = scraperObject.allPropertyIds;
        let allPropIds = allPropIdsString.split(',');
        let propertiesMap = null;
        if (scraperObject.searchPageScraper === 'RESIDENTAIL_PROJECTS_SEARCH_PAGE_SCRAPER' ||
            scraperObject.searchPageScraper === 'COMMERCIAL_PROJECTS_SEARCH_PAGE_SCRAPER') {
            allPropIds = allPropIds.map(propid => {
                const tokens = propid.split('-');
                return tokens[tokens.length - 1];
            });
            propertiesMap = await dbInstance.getProjects(allPropIds, function(index) {
                if (index < allPropIds.length) {
                    strDownloadProgress = `Downloading ${index+1} Property of ${allPropIds.length} Properties `;
                } else {
                    strDownloadProgress = ``;
                }
                updateView();
            });
        } else {
            propertiesMap = await dbInstance.getProperties(allPropIds, function(index) {
                if (index < allPropIds.length) {
                    strDownloadProgress = `Downloading ${index+1} Property of ${allPropIds.length} Properties `;
                } else {
                    strDownloadProgress = ``;
                }
                updateView();
            });
        }

        console.log(propertiesMap);
        Object.keys(propertiesMap)
            .filter(key => propertiesMap[key] && propertiesMap[key].length > 0)
            .forEach(async function(key) {
                const matchingScraper = PRODUCT_SCRAPERS.find(scraper => scraper.name === key);
                if (matchingScraper) {
                    let filename = matchingScraper.filename;
                    if (scraperObject && scraperObject.cityName && scraperObject.categoryName) {
                        filename = `${scraperObject.categoryName}-${scraperObject.cityName}-${matchingScraper.filename}`;
                    }

                    await downloadCrawlResultsAsCSV(propertiesMap[key], matchingScraper, filename);
                }

            });
    });




}

async function downloadCrawlResultsAsCSV(results, scraperConfig, filename) {
    console.log(results);
    let text = 'urls';

    scraperConfig.fields
        .sort((field1, field2) => field1.rank > field2.rank ? 1 : -1)
        .forEach((field) => {
            text = `${text},${field.name}`;
        });
    text = text + '\n';

    results.filter(result => result).forEach((crawlResult, resultIndex) => {
        console.log(crawlResult);
        scraperConfig
            .fields
            .sort((field1, field2) => field1.rank > field2.rank ? 1 : -1)
            .forEach((field) => {
                const currentField = crawlResult.find(resultField => resultField.name === field.name);

                if (currentField && currentField.value) {
                    let fieldValue = currentField.value.trim().replace(/[\r\n\t]+/g, ' ');
                    fieldValue = formatField(currentField.name, fieldValue);
                    text = text + ',' + fieldValue;

                } else {
                    text = text + ',';
                }
            });
        text = text + '\n';


    });


    download(filename, text);





}

function download(filename, text) {
    chrome.downloads.download({
        url: 'data:text/csv;charset=utf-8,' + encodeURIComponent(text),
        filename: filename + '.csv',
        saveAs: true
    });


}



function findCityNameNCategory() {
    let isSearchPage = false;
    if (DomainProps.domain === '99acres.com' && DomainProps.pageUrl) {
        const tokens = DomainProps.pageUrl.split(`/`);
        if (tokens[3] === 'search') {
            categoryName = tokens[4] + '_' + tokens[5] + '_' + tokens[6];
            cityName = tokens[7].split('?')[0];
        }

    }
    return isSearchPage;
}


function formatField(fieldName, fieldValue) {
    fieldValue = fieldValue.replace(/\s\s+/g, ' ');
    fieldValue = fieldValue.replace(/:/g, '');
    fieldValue = fieldValue.replace("\u20b9", '');
    let formatedValue = fieldValue;
    switch (fieldName) {
        case 'Location':
            {
                formatedValue = fieldValue.replace('in ', '');
                formatedValue = formatedValue.replace('Address', '');
                formatedValue = formatedValue.replace(`What's Nearby`, '');
                const tokens = formatedValue.split(',');
                const hydIndex = tokens.findIndex(token => token.trim().toLowerCase() === 'hyderabad');
                if (hydIndex > 0) {
                    formatedValue = tokens[hydIndex - 1];
                }

                break;
            }
        case 'Address':
            {
                formatedValue = fieldValue.replace('in ', '');
                formatedValue = formatedValue.replace('Address', '');
                formatedValue = formatedValue.replace(`What's Nearby`, '');
                break;
            }


        case 'Propertyid':
            formatedValue = `https://99acres.com/${fieldValue}`;
            break;
        case 'Projectid':
            formatedValue = `https://99acres.com/--npxid-${fieldValue}`;
            break;
        case 'Dearler URL':
            formatedValue = `https://99acres.com/xx-drid-${fieldValue}`;
            break;
        case 'Contact Type':
            switch (fieldValue) {
                case 'Contact DealerFREE':
                    formatedValue = 'Dealer';
                    break;
                case 'Contact OwnerFREE':
                    formatedValue = 'Owner';
                    break;
            }
            break;
        case 'Posted By':
            {
                if (fieldValue) {
                    let index = fieldValue.search('by ');
                    if (index !== -1) {
                        formatedValue = fieldValue.substring(index + 3);
                    }
                }
                break;
            }


        case 'Towers':
            {
                formatedValue = fieldValue.replace('No. of Towers', '');
                formatedValue = formatedValue.replace('Towers', '');
                break;

            }
        case 'Floors':
            {
                formatedValue = fieldValue.replace('No. of Floors', '');
                formatedValue = formatedValue.replace('Floors', '');
                break;

            }
        case 'Units':
            {
                formatedValue = fieldValue.replace('No. of Units', '');
                formatedValue = formatedValue.replace('Units', '');
                break;

            }
        case 'Total Project Area':
            {
                formatedValue = fieldValue.replace('Total Project Area', '');
                break;

            }
        case 'Open Area':
            {
                formatedValue = fieldValue.replace('Open Area', '');
                break;

            }
        case 'Possesion':
            {
                formatedValue = fieldValue.replace('Possession', '');
                formatedValue = formatedValue.replace('View Photos', '');
                break;

            }
        case 'Configuration':
            {
                formatedValue = fieldValue.replace('Configurations', '');
                formatedValue = formatedValue.replace('View Floor Plans', '');
                break;

            }


    }
    formatedValue = formatedValue.replace(/\,/g, ' ');
    if (fieldValue === 'undefined') {
        formatedValue = '';
    }


    return formatedValue;
}