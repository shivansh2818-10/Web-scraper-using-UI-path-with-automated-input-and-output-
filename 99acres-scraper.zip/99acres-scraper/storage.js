function getStorageInstance() {
    const KEY_SCRAPER_ON = 'KEY_SCRAPER_ON';
    const KEY_SKIP_SEARCH_PAGE = 'KEY_SKIP_SEARCH_PAGE';
    const KEY_PRODUCT_INDEX = 'KEY_PRODUCT_INDEX';
    const KEY_PRODUCTIDS = 'KEY_PRODUCT_IDS';
    const KEY_ALL_SEARCH_PAGES_INDEXED = 'KEY_ALL_SEARCH_PAGES_INDEXED';



    function setStorage(key, value) {
        return new Promise((resolve, reject) => {
            const obj = {};
            obj[key] = value;
            chrome.storage.local.set(obj, function() {
                resolve();
            });
        });
    }

    function getStorage(key) {
        return new Promise((resolve, reject) => {
            chrome.storage.local.get(key, function(result) {
                resolve(result[key]);
            });
        });
    }



    function startScraper() {
        return setStorage(KEY_SCRAPER_ON, "ON");
    }

    function stopScraper() {
        return setStorage(KEY_SCRAPER_ON, "OFF");
    }

    function pauseScraper() {
        return setStorage(KEY_SCRAPER_ON, "PAUSED");
    }

    function getScraperStatus() {
        return getStorage(KEY_SCRAPER_ON);
    }

    async function addProductIds(productids) {

        if (productids.length > 0) {
            const newcsvProductIds = productids
                .reduce((accumulator, propertyid, index) => accumulator + ',' + propertyid);

            let csvPropertyIds = await getProductIds();

            if (csvPropertyIds && csvPropertyIds.length !== 0) {
                csvPropertyIds = csvPropertyIds + ',' + newcsvProductIds;
            } else {
                csvPropertyIds = newcsvProductIds;
            }

            await setStorage(KEY_PRODUCTIDS, csvPropertyIds);
        }


    }

    async function getProductIds() {
        const csvPropertyIds = await getStorage(KEY_PRODUCTIDS);
        return csvPropertyIds;
    }

    async function resetProductIds() {
        await setStorage(KEY_PRODUCTIDS, '');
        await resetProductIndex(0);
    }



    async function getSkipSearchPage() {
        const skipSearchPage = await getStorage(KEY_SKIP_SEARCH_PAGE);
        if (skipSearchPage && skipSearchPage === 'TRUE') {
            return true;
        } else {
            return false;
        }
    }

    async function enableSkipSearchPage() {
        await setStorage(KEY_SKIP_SEARCH_PAGE, 'TRUE');
    }

    async function disableSkipSearchPage() {
        await setStorage(KEY_SKIP_SEARCH_PAGE, 'FALSE');
    }

    async function setProductIndex(index) {
        await setStorage(KEY_PRODUCT_INDEX, `${index}`);
    }

    async function resetProductIndex() {
        await setStorage(KEY_PRODUCT_INDEX, 0);
    }

    async function getNextProductId() {
        let nextProductId = '';
        let currentProductIndex = -1;
        let nextIndexString = -1;
        nextIndexString = await getStorage(KEY_PRODUCT_INDEX);
        console.log(`nextIndexString:${nextIndexString}`);
        if (nextIndexString !== -1) {
            currentProductIndex = parseInt(nextIndexString, 10);
        }
        if (currentProductIndex !== -1) {
            const allProductIdCSV = await getProductIds();
            const allProductIds = allProductIdCSV.split(',');
            nextProductId = allProductIds[currentProductIndex];
            await setProductIndex(currentProductIndex + 1);
        }
        return nextProductId;

    }

    async function getAllSearchPagesIndexed() {
        const allSearchPagesIndexed = await getStorage(KEY_ALL_SEARCH_PAGES_INDEXED);
        if (allSearchPagesIndexed && allSearchPagesIndexed === 'TRUE') {
            return true;
        } else {
            return false;
        }
    }

    async function enableAllSearchPagesIndexed() {
        await setStorage(KEY_ALL_SEARCH_PAGES_INDEXED, 'TRUE');
    }

    async function disableAllSearchPagesIndexed() {
        await setStorage(KEY_ALL_SEARCH_PAGES_INDEXED, 'FALSE');
    }



    return {
        startScraper: startScraper,
        stopScraper: stopScraper,
        pauseScraper: pauseScraper,
        getScraperStatus: getScraperStatus,

        getProductIds: getProductIds,
        resetProductIds: resetProductIds,
        addProductIds: addProductIds,



        getSkipSearchPage: getSkipSearchPage,
        enableSkipSearchPage: enableSkipSearchPage,
        disableSkipSearchPage: disableSkipSearchPage,

        getNextProductId: getNextProductId,

        getAllSearchPagesIndexed: getAllSearchPagesIndexed,
        enableAllSearchPagesIndexed: enableAllSearchPagesIndexed,
        disableAllSearchPagesIndexed: disableAllSearchPagesIndexed

    }

}